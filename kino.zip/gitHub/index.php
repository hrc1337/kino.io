<!DOCTYPE html>
<html lang="en">
<head>
	
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, minimum-scale=1.0, initial-scale=1.0, user-scalable=no">
<title>NewsApi</title>
<link rel="stylesheet" href="css/md-css.css">
<link rel="stylesheet" href="css/md-icons.min.css">
<link href="https://fonts.googleapis.com/css?family=Inconsolata:400,700|Poppins:400,400i,500,700,700i&amp;subset=latin-ext" rel="stylesheet">
<link rel="stylesheet" href="./style.min.css">
    <center>
   
   <div class="index-splash-image"></div>
   <a class="button splash" href="vhod.php">Начать</a>

</center>
</body>
</body>
	